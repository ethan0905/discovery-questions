"use client"

import DiscoveryCopilot from "../discovery-copilot"

export default function Page() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-white p-6">
      <DiscoveryCopilot />
    </main>
  )
}
